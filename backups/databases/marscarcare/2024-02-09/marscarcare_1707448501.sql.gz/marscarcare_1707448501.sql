-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: marscarcare
-- ------------------------------------------------------
-- Server version	8.0.36-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account_types`
--

DROP TABLE IF EXISTS `account_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_types` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `account_type` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `account_type_slug` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_types`
--

LOCK TABLES `account_types` WRITE;
/*!40000 ALTER TABLE `account_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset_assignment`
--

DROP TABLE IF EXISTS `asset_assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asset_assignment` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int unsigned NOT NULL,
  `asset_id` int unsigned NOT NULL,
  `center_id` int NOT NULL,
  `remarks` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `closure_date` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `status` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `charge_asset` tinyint NOT NULL,
  `asset_charging_month` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `condition` int NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `asset_assignment_employee_id_foreign` (`employee_id`),
  KEY `asset_assignment_asset_id_foreign` (`asset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset_assignment`
--

LOCK TABLES `asset_assignment` WRITE;
/*!40000 ALTER TABLE `asset_assignment` DISABLE KEYS */;
/*!40000 ALTER TABLE `asset_assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset_assignment_status`
--

DROP TABLE IF EXISTS `asset_assignment_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asset_assignment_status` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset_assignment_status`
--

LOCK TABLES `asset_assignment_status` WRITE;
/*!40000 ALTER TABLE `asset_assignment_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `asset_assignment_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset_categories`
--

DROP TABLE IF EXISTS `asset_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asset_categories` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset_categories`
--

LOCK TABLES `asset_categories` WRITE;
/*!40000 ALTER TABLE `asset_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `asset_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset_conditions`
--

DROP TABLE IF EXISTS `asset_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asset_conditions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `condition` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `creator_ip` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `updater_ip` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset_conditions`
--

LOCK TABLES `asset_conditions` WRITE;
/*!40000 ALTER TABLE `asset_conditions` DISABLE KEYS */;
/*!40000 ALTER TABLE `asset_conditions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `asset` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `asset_category` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `model` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `make` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `rate` double(8,2) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
INSERT INTO `assets` VALUES (1,'assest1','Vehicle','1001','make1','Test Asset Model',20.00,1,'2024-01-18 23:44:23','2024-01-18 23:44:23'),(2,'assest2','Bike','top2','20222','Test Asset Model update',40.00,0,'2024-01-18 23:51:39','2024-01-31 06:39:25'),(3,'assest2','Car','top','2022','Test Asset Model',30.00,0,'2024-01-21 05:11:36','2024-01-21 05:11:36'),(4,'assest23','Car','top','2022','Test Asset Model',300.00,1,'2024-01-30 08:51:33','2024-01-31 08:55:14'),(5,'assest2','Bike','top','2022','Test Asset Model',30.00,1,'2024-01-30 08:51:51','2024-01-30 08:51:51'),(6,'saten','1234567890','satendra6id@gmail.com','fasdfas','',0.00,1,'2024-01-31 06:26:48','2024-01-31 07:43:35'),(7,'saten','1234567890','7idwaladata@gmail.com','fasdfas','',0.00,1,'2024-01-31 07:40:31','2024-01-31 07:42:25'),(8,'swswsw222','lkajsdflajsl','alksjdflaksdjf','alksjdfalksdjf','lakjsdflkajsdfl',76.00,1,'2024-01-31 08:49:02','2024-01-31 08:57:04');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance`
--

DROP TABLE IF EXISTS `attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `center_id` int unsigned NOT NULL,
  `date` date NOT NULL,
  `in_time` time DEFAULT NULL,
  `out_time` time DEFAULT NULL,
  `attendance` int DEFAULT NULL,
  `attendance_on_weekoff` int DEFAULT NULL,
  `working_hours` time DEFAULT NULL,
  `is_late` int DEFAULT NULL,
  `remarks` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `lat` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `lng` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `out_lat` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `out_lng` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `attendance_center_id_foreign` (`center_id`)
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance`
--

LOCK TABLES `attendance` WRITE;
/*!40000 ALTER TABLE `attendance` DISABLE KEYS */;
INSERT INTO `attendance` VALUES (4,'MCC-00012',11,'2024-02-05','09:30:00','19:10:20',1,NULL,'09:40:20',NULL,NULL,0,'28.84893','72.7828','28.84893','72.7828','2024-02-04 06:49:09','2024-02-04 08:31:46',123,123),(5,'MCC-00012',11,'2024-02-06','09:30:00',NULL,1,NULL,NULL,NULL,NULL,0,'28.84893','72.7828',NULL,NULL,'2024-02-05 10:40:02','2024-02-05 10:40:02',123,123),(6,'MCC-00012',11,'2024-02-06','09:30:00','19:10:00',2,NULL,'09:40:00',NULL,NULL,0,'28.84893','72.7828','28.84893','72.7828','2024-02-05 10:41:21','2024-02-06 18:14:39',123,123),(7,'MCC-00012',11,'2024-02-01','09:30:00','19:10:00',1,NULL,'09:40:00',NULL,NULL,0,'28.84893','72.7828','28.84893','72.7828','2024-02-05 10:55:16','2024-02-08 09:19:51',123,123),(8,'MCC-00012',11,'2024-02-01','09:30:00','19:10:00',1,NULL,'09:40:00',NULL,NULL,0,'28.84893','72.7828','28.84893','72.7828','2024-02-05 16:56:32','2024-02-08 09:19:51',123,123),(9,'MCC-00012',11,'2024-02-05','09:30:00',NULL,NULL,NULL,NULL,NULL,NULL,0,'28.84893','72.7828',NULL,NULL,'2024-02-06 03:05:23','2024-02-06 03:05:23',123,123),(10,'MCC-00012',11,'2024-01-02','09:30:00',NULL,NULL,NULL,NULL,NULL,NULL,0,'28.84893','72.7828',NULL,NULL,'2024-02-06 18:14:14','2024-02-06 18:14:14',123,123),(11,'hrAdmin',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:09:11','2024-02-08 05:09:11',1,1),(12,'MCC-0001',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:09:11','2024-02-08 05:09:11',1,1),(13,'MCC-0002',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:09:11','2024-02-08 05:09:11',1,1),(14,'MCC-0003',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:09:11','2024-02-08 05:09:11',1,1),(15,'MCC-0004',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:09:11','2024-02-08 05:09:11',1,1),(16,'MCC-0005',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:09:11','2024-02-08 05:09:11',1,1),(17,'MCC-0006',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:09:11','2024-02-08 05:09:11',1,1),(18,'MCC-0007',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:09:11','2024-02-08 05:09:11',1,1),(19,'MCC-0008',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:09:11','2024-02-08 05:09:11',1,1),(20,'MCC-0009',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:09:11','2024-02-08 05:09:11',1,1),(21,'MCC-00010',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:09:11','2024-02-08 05:09:11',1,1),(22,'MCC-00011',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:09:11','2024-02-08 05:09:11',1,1),(23,'MCC-00012',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:09:11','2024-02-08 05:09:11',1,1),(24,'MCC-00013',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:09:11','2024-02-08 05:09:11',1,1),(25,'MCC-00014',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:09:11','2024-02-08 05:09:11',1,1),(26,'MCC-00015',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:09:11','2024-02-08 05:09:11',1,1),(27,'MCC-00016',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:09:11','2024-02-08 05:09:11',1,1),(28,'MCC-00017',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:09:11','2024-02-08 05:09:11',1,1),(29,'9845699986',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:09:11','2024-02-08 05:09:11',1,1),(30,'1',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:09:11','2024-02-08 05:09:11',1,1),(31,'MCC-00025',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:09:11','2024-02-08 05:09:11',1,1),(32,'MCC-00026',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:09:11','2024-02-08 05:09:11',1,1),(33,'MCC-00027',11,'2024-02-08','09:30:00','19:10:00',2,NULL,'09:40:00',NULL,NULL,0,NULL,NULL,'28.84893','72.7828','2024-02-08 05:09:11','2024-02-08 09:57:32',1,1),(34,'hrAdmin',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:44:28','2024-02-08 05:44:28',1,1),(35,'MCC-0001',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:44:28','2024-02-08 05:44:28',1,1),(36,'MCC-0002',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:44:28','2024-02-08 05:44:28',1,1),(37,'MCC-0003',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:44:28','2024-02-08 05:44:28',1,1),(38,'MCC-0005',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:44:28','2024-02-08 05:44:28',1,1),(39,'MCC-0004',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:44:28','2024-02-08 05:44:28',1,1),(40,'MCC-0006',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:44:28','2024-02-08 05:44:28',1,1),(41,'MCC-0007',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:44:28','2024-02-08 05:44:28',1,1),(42,'MCC-0008',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:44:28','2024-02-08 05:44:28',1,1),(43,'MCC-0009',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:44:28','2024-02-08 05:44:28',1,1),(44,'MCC-00010',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:44:28','2024-02-08 05:44:28',1,1),(45,'MCC-00011',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:44:28','2024-02-08 05:44:28',1,1),(46,'MCC-00012',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:44:28','2024-02-08 05:44:28',1,1),(47,'MCC-00013',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:44:28','2024-02-08 05:44:28',1,1),(48,'MCC-00014',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:44:28','2024-02-08 05:44:28',1,1),(49,'MCC-00015',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:44:28','2024-02-08 05:44:28',1,1),(50,'MCC-00016',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:44:28','2024-02-08 05:44:28',1,1),(51,'MCC-00017',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:44:28','2024-02-08 05:44:28',1,1),(52,'9845699986',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:44:28','2024-02-08 05:44:28',1,1),(53,'1',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:44:28','2024-02-08 05:44:28',1,1),(54,'MCC-00025',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:44:28','2024-02-08 05:44:28',1,1),(55,'MCC-00026',11,'2024-02-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-02-08 05:44:28','2024-02-08 05:44:28',1,1),(56,'MCC-00027',11,'2024-02-08','09:30:00','19:10:00',2,NULL,'09:40:00',NULL,NULL,0,NULL,NULL,'28.84893','72.7828','2024-02-08 05:44:28','2024-02-08 09:57:32',1,1),(57,'MCC-00028',11,'2024-02-08','09:30:00','19:10:00',2,NULL,'09:40:00',NULL,NULL,0,'28.84893','72.7828','28.84893','72.7828','2024-02-08 06:04:43','2024-02-08 09:24:00',123,123);
/*!40000 ALTER TABLE `attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance_types`
--

DROP TABLE IF EXISTS `attendance_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance_types` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `attendance` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance_types`
--

LOCK TABLES `attendance_types` WRITE;
/*!40000 ALTER TABLE `attendance_types` DISABLE KEYS */;
INSERT INTO `attendance_types` VALUES (1,'Present',0,'2024-02-07 16:08:34','2024-02-07 16:08:34',1,1),(2,'Absent',0,'2024-02-07 16:08:34','2024-02-07 16:08:34',1,1),(3,'Week Off',0,'2024-02-08 16:47:16','2024-02-08 16:47:16',1,1),(4,'Not marked',0,'2024-02-08 16:47:16','2024-02-08 16:47:16',1,1),(5,'Half day',0,'2024-02-08 16:47:41','2024-02-08 16:47:41',1,1),(6,'Holiday',0,'2024-02-08 16:47:41','2024-02-08 16:47:41',1,1);
/*!40000 ALTER TABLE `attendance_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank_details`
--

DROP TABLE IF EXISTS `bank_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bank_details` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `bank_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `account_number` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `account_type` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `ifsc_code` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bank_details_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank_details`
--

LOCK TABLES `bank_details` WRITE;
/*!40000 ALTER TABLE `bank_details` DISABLE KEYS */;
INSERT INTO `bank_details` VALUES (1,13,'KOTAK MAHINDRA','AGFPD6305V','DL-0420060328457','DL-0420060328457',0,'2024-01-21 18:42:40','2024-01-21 18:42:40',1,1),(2,16,'KOTAK MAHINDRA','AGFPD6305V','DL-0420060328457','DL-0420060328457',0,'2024-01-24 18:56:27','2024-01-24 18:56:27',1,1),(3,18,'KOTAK MAHINDRA','AGFPD6305V','DL-0420060328457','DL-0420060328457',0,'2024-01-24 19:04:17','2024-01-24 19:04:17',1,1);
/*!40000 ALTER TABLE `bank_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `centers`
--

DROP TABLE IF EXISTS `centers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `centers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `store_id` int unsigned DEFAULT NULL,
  `asm_id` int unsigned DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `center_time` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '9:45 AM',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `centers_store_id_foreign` (`store_id`),
  KEY `centers_asm_id_foreign` (`asm_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `centers`
--

LOCK TABLES `centers` WRITE;
/*!40000 ALTER TABLE `centers` DISABLE KEYS */;
INSERT INTO `centers` VALUES (4,1,20,'ESPIRIT TOYOTA- WASHing','noida','7:58 PM',0,'2024-02-03 14:30:15','2024-02-03 14:30:15',1,1),(2,1,1,'ESPIRIT TOYOTA- WASHING','Noida','9:30 AM',1,'2024-01-31 12:12:16','2024-02-03 14:48:57',1,1),(3,1,1,'ESPIRIT TOYOTA- WASHING','Noida','9:30 AM',1,'2024-01-31 12:29:55','2024-02-03 14:49:46',1,1),(5,1,20,'Satendra Singh','noida','5:37 PM',1,'2024-02-03 12:11:18','2024-02-03 14:52:04',1,1),(6,1,20,'Satendra Singh','noida','5:41 PM',1,'2024-02-03 12:11:54','2024-02-03 14:50:22',1,1),(7,1,20,'Satendra Singh','noida','5:41 PM',1,'2024-02-03 12:14:19','2024-02-03 14:51:27',1,1),(8,1,1,'ESPIRIT TOYOTA- WASHING','Noida','9:30 AM',0,'2024-02-03 12:18:06','2024-02-03 12:18:06',1,1),(9,1,1,'ESPIRIT TOYOTA- WASHING','Noida','9:30 AM',0,'2024-02-03 12:18:41','2024-02-03 12:18:41',1,1),(10,1,1,'ESPIRIT TOYOTA- WASHING','Noida','9:30 AM',0,'2024-02-03 12:20:29','2024-02-03 12:20:29',1,1),(11,1,1,'ESPIRIT TOYOTA- WASHING','Noida','9:30 AM',0,'2024-02-03 12:21:45','2024-02-03 12:21:45',1,1),(12,1,1,'ESPIRIT TOYOTA- WASHING','Noida','9:30 AM',0,'2024-02-03 12:22:39','2024-02-03 12:22:39',1,1),(13,1,1,'ESPIRIT TOYOTA- WASHING','Noida','9:30 AM',0,'2024-02-03 12:23:31','2024-02-03 12:23:31',1,1),(14,1,1,'ESPIRIT TOYOTA- WASHING','Noida','9:30 AM',0,'2024-02-03 12:23:47','2024-02-03 12:23:47',1,1),(15,1,1,'ESPIRIT TOYOTA- WASHING','Noida','9:30 AM',0,'2024-02-03 12:24:49','2024-02-03 12:24:49',1,1),(16,1,1,'ESPIRIT TOYOTA- WASHING','Noida','9:30 AM',0,'2024-02-03 12:25:13','2024-02-03 12:25:13',1,1),(17,1,1,'ESPIRIT TOYOTA- WASHING','Noida','9:30 AM',0,'2024-02-03 12:25:33','2024-02-03 12:25:33',1,1),(18,1,1,'ESPIRIT TOYOTA- WASHING','Noida','9:30 AM',0,'2024-02-03 12:27:33','2024-02-03 12:27:33',1,1),(19,1,1,'ESPIRIT TOYOTA- WASHING','Noida','9:30 AM',0,'2024-02-03 12:28:10','2024-02-03 12:28:10',1,1),(20,1,20,'Satendra Singh','noida','5:59 PM',0,'2024-02-03 12:29:59','2024-02-03 12:29:59',1,1);
/*!40000 ALTER TABLE `centers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deleted_employees`
--

DROP TABLE IF EXISTS `deleted_employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deleted_employees` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `father_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `employee_id` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deleted_employees`
--

LOCK TABLES `deleted_employees` WRITE;
/*!40000 ALTER TABLE `deleted_employees` DISABLE KEYS */;
/*!40000 ALTER TABLE `deleted_employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emergency_details`
--

DROP TABLE IF EXISTS `emergency_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `emergency_details` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `contact_person` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `relation` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `contact_number` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `emergency_details_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emergency_details`
--

LOCK TABLES `emergency_details` WRITE;
/*!40000 ALTER TABLE `emergency_details` DISABLE KEYS */;
INSERT INTO `emergency_details` VALUES (1,10,'ABC','Father','973473922',0,'2024-01-21 17:51:41','2024-01-21 17:51:41',1,1),(2,11,'ABC','Father','973473922',0,'2024-01-21 17:53:22','2024-01-21 17:53:22',1,1),(3,12,'ABC','Father','973473922',0,'2024-01-21 18:39:17','2024-01-21 18:39:17',1,1),(4,13,'ABC','Father','973473922',0,'2024-01-21 18:42:35','2024-01-21 18:42:35',1,1),(5,14,'ABC','Father','973473922',0,'2024-01-21 19:34:01','2024-01-21 19:34:01',1,1),(6,15,'ABC','Father','973473922',0,'2024-01-24 18:53:57','2024-01-24 18:53:57',1,1),(7,16,'ABC','Father','973473922',0,'2024-01-24 18:56:26','2024-01-24 18:56:26',1,1),(8,18,'ABC','Father','973473922',0,'2024-01-24 19:04:16','2024-01-24 19:04:16',1,1);
/*!40000 ALTER TABLE `emergency_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_center`
--

DROP TABLE IF EXISTS `employee_center`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_center` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int unsigned NOT NULL,
  `center_id` int unsigned NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_center_employee_id_foreign` (`employee_id`),
  KEY `employee_center_center_id_foreign` (`center_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_center`
--

LOCK TABLES `employee_center` WRITE;
/*!40000 ALTER TABLE `employee_center` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_center` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_codes`
--

DROP TABLE IF EXISTS `employee_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_codes` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `employee_code` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_codes`
--

LOCK TABLES `employee_codes` WRITE;
/*!40000 ALTER TABLE `employee_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_document_copies`
--

DROP TABLE IF EXISTS `employee_document_copies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_document_copies` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `adhaar` tinyint NOT NULL DEFAULT '0',
  `pan` tinyint NOT NULL DEFAULT '0',
  `address_proof` tinyint NOT NULL DEFAULT '0',
  `education_proof` tinyint NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_document_copies`
--

LOCK TABLES `employee_document_copies` WRITE;
/*!40000 ALTER TABLE `employee_document_copies` DISABLE KEYS */;
INSERT INTO `employee_document_copies` VALUES (1,13,0,1,0,1,0,'2024-01-21 18:42:47','2024-01-21 18:42:47',1,1),(2,16,0,1,0,1,0,'2024-01-24 18:56:30','2024-01-24 18:56:30',1,1),(3,18,0,1,0,1,0,'2024-01-24 19:04:20','2024-01-24 19:04:20',1,1);
/*!40000 ALTER TABLE `employee_document_copies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_documents`
--

DROP TABLE IF EXISTS `employee_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_documents` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `document` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `document_url` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_documents_user_id_foreign` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_documents`
--

LOCK TABLES `employee_documents` WRITE;
/*!40000 ALTER TABLE `employee_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_history`
--

DROP TABLE IF EXISTS `employee_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_history` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int unsigned NOT NULL,
  `activity` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_history`
--

LOCK TABLES `employee_history` WRITE;
/*!40000 ALTER TABLE `employee_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_image_data`
--

DROP TABLE IF EXISTS `employee_image_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_image_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `employee_id` varchar(255) NOT NULL,
  `image_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `init_vector` text NOT NULL,
  `face_descriptor` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_image_data`
--

LOCK TABLES `employee_image_data` WRITE;
/*!40000 ALTER TABLE `employee_image_data` DISABLE KEYS */;
INSERT INTO `employee_image_data` VALUES (1,1,'MCC-0001','/home/amit/amit/marscarcare/src/services/hr/uploads/MCC-0001.jpeg','If1nKjQsqd4UEErwUFncxg==','db9816f219ae60eb2f1458e97a651c27','2024-01-26 22:34:35','2024-01-26 22:34:35',1,1),(2,5,'MCC-0005','/home/amit/amit/marscarcare/src/services/hr/uploads/MCC-0005.jpeg','MzQyZDczMGU4ZGU4ZjgyNGNmYTM0MjBjYzFjMDJkNjQ=','ce1fbe2a8be147b1e1dbbe4b2b2c09e1','2024-01-27 02:15:38','2024-01-27 02:15:38',1,1),(17,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','Optional String','Optional String','2024-01-27 21:41:42','2024-01-27 21:41:42',1,1),(19,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','Optional String','Optional String','2024-01-27 21:45:17','2024-01-27 21:45:17',1,1),(20,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','Optional String','Optional String','2024-01-27 21:49:33','2024-01-27 21:49:33',1,1),(21,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 22:41:45','2024-01-27 22:41:45',1,1),(22,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 22:42:54','2024-01-27 22:42:54',1,1),(23,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 22:45:28','2024-01-27 22:45:28',1,1),(24,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 22:47:26','2024-01-27 22:47:26',1,1),(25,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 22:47:58','2024-01-27 22:47:58',1,1),(26,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 22:48:30','2024-01-27 22:48:30',1,1),(27,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 22:49:11','2024-01-27 22:49:11',1,1),(28,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 22:54:44','2024-01-27 22:54:44',1,1),(29,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 22:56:55','2024-01-27 22:56:55',1,1),(30,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.png','asdfadsf','asdfasdfasdf','2024-01-27 23:15:37','2024-01-27 23:15:37',1,1),(31,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 23:18:15','2024-01-27 23:18:15',1,1),(32,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 23:18:16','2024-01-27 23:18:16',1,1),(33,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 23:19:27','2024-01-27 23:19:27',1,1),(34,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 23:21:22','2024-01-27 23:21:22',1,1),(35,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 23:24:15','2024-01-27 23:24:15',1,1),(36,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 23:24:15','2024-01-27 23:24:15',1,1),(37,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 23:24:18','2024-01-27 23:24:18',1,1),(38,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 23:24:28','2024-01-27 23:24:28',1,1),(39,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 23:24:41','2024-01-27 23:24:41',1,1),(40,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 23:25:03','2024-01-27 23:25:03',1,1),(41,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 23:25:45','2024-01-27 23:25:45',1,1),(42,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 23:25:46','2024-01-27 23:25:46',1,1),(43,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 23:25:47','2024-01-27 23:25:47',1,1),(44,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 23:25:55','2024-01-27 23:25:55',1,1),(45,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-27 23:26:15','2024-01-27 23:26:15',1,1),(46,5,'MCC-0006','/home/amit/amit/marscarcare/src/services/hr/uploads/MCC-0006.jpeg','YTE2MjJlYjIxYWJhZjA2ODY1MzFhNGIzMGIzMGU2Mzg=','289b61c0bdd070355849d9711769bfc0','2024-01-28 06:55:54','2024-01-28 06:55:54',1,1),(47,5,'MCC-0007','/home/amit/amit/marscarcare/src/services/hr/uploads/MCC-0007.jpeg','MzcwMjY2ZDRiZmYyYjYwOWZhOGNlMjI5NGE1NDZkZDk=','5c6e40e1a2f6c986677fafc157c8cfcf','2024-01-28 06:57:50','2024-01-28 06:57:50',1,1),(48,5,'MCC-0002','/home/amit/amit/marscarcare/src/services/hr/uploads/MCC-0002.jpeg','ZmE0MTM5OTY2NzU0N2M1NjFiZjM3YjMxOThjNTIwMTc=','de4b4002fe8fb6ad1a37a8d06a5c81d9','2024-01-28 06:58:32','2024-01-28 06:58:32',1,1),(49,5,'MCC-00016','/home/amit/amit/marscarcare/src/services/hr/uploads/MCC-00016.jpeg','MWUyYzM0YzUwNDlkZjk1N2MyMDQxZmMwYjdmZGZmYjE=','255cd2b023c847860c302a5339c3991a','2024-01-28 07:04:42','2024-01-28 07:04:42',1,1),(50,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-28 15:39:27','2024-01-28 15:39:27',1,1),(51,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-28 18:32:30','2024-01-28 18:32:30',1,1),(52,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-28 20:02:06','2024-01-28 20:02:06',1,1),(53,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-28 20:14:17','2024-01-28 20:14:17',1,1),(54,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-28 20:42:07','2024-01-28 20:42:07',1,1),(55,18,'MCC-00017','/home/amit/amit/ytface/static/uploads','asdfadsf','asdfasdfasdf','2024-01-28 21:30:15','2024-01-28 21:30:15',1,1),(56,18,'MCC-00017','/home/amit/amit/ytface/static/uploads','asdfadsf','asdfasdfasdf','2024-01-28 21:35:51','2024-01-28 21:35:51',1,1),(57,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-28 21:40:56','2024-01-28 21:40:56',1,1),(58,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-28 23:30:40','2024-01-28 23:30:40',1,1),(59,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-28 23:31:30','2024-01-28 23:31:30',1,1),(60,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-29 04:59:21','2024-01-29 04:59:21',1,1),(61,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-29 18:15:47','2024-01-29 18:15:47',1,1),(62,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfadsf','asdfasdfasdf','2024-01-29 19:47:15','2024-01-29 19:47:15',1,1),(63,1,'hrAdmin','/home/amit/amit/ytface/static/uploads/hrAdmin.jpg','asdfadsf','asdfasdfasdf','2024-01-29 19:54:29','2024-01-29 19:54:29',1,1),(64,1,'hrAdmin','/home/amit/amit/ytface/static/uploads/hrAdmin.jpg','asdfadsf','asdfasdfasdf','2024-01-29 20:08:55','2024-01-29 20:08:55',1,1),(65,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfasd','asdfdf','2024-01-30 16:29:28','2024-01-30 16:29:28',1,1),(66,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfasd','asdfdf','2024-01-30 16:58:18','2024-01-30 16:58:18',1,1),(67,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfasd','asdfdf','2024-01-30 17:36:03','2024-01-30 17:36:03',1,1),(68,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfasd','asdfdf','2024-01-30 17:36:05','2024-01-30 17:36:05',1,1),(69,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfasd','asdfdf','2024-01-30 17:36:16','2024-01-30 17:36:16',1,1),(70,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfasd','asdfdf','2024-01-30 17:36:28','2024-01-30 17:36:28',1,1),(71,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfasd','asdfdf','2024-01-30 17:38:40','2024-01-30 17:38:40',1,1),(72,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfasd','asdfdf','2024-01-31 12:26:32','2024-01-31 12:26:32',1,1),(73,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfasd','asdfdf','2024-01-31 12:29:15','2024-01-31 12:29:15',1,1),(74,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfasd','asdfdf','2024-01-31 12:29:22','2024-01-31 12:29:22',1,1),(75,3,'MCC-0002',NULL,'asdfasd','asdfdf','2024-01-31 12:52:47','2024-01-31 12:52:47',1,1),(76,18,'MCC-00017','/home/amit/amit/ytface/static/uploads/MCC-00017.jpg','asdfasd','asdfdf','2024-01-31 12:56:27','2024-01-31 12:56:27',1,1),(77,4,'MCC-0003','/home/amit/amit/ytface/static/uploads/MCC-0003.jpg','asdfasd','asdfdf','2024-01-31 12:58:54','2024-01-31 12:58:54',1,1),(78,1,'hrAdmin','/home/amit/amit/FaceRecognitionFinel/static/uploads/hrAdmin.jpg','asdfasd','asdfdf','2024-02-01 16:52:59','2024-02-01 16:52:59',1,1),(79,1,'hrAdmin','/home/amit/amit/FaceRecognitionFinel/static/uploads/hrAdmin.jpg','asdfasd','asdfdf','2024-02-01 16:54:47','2024-02-01 16:54:47',1,1),(80,1,'hrAdmin','/home/amit/amit/FaceRecognitionFinel/static/uploads/hrAdmin.jpg','asdfasd','asdfdf','2024-02-01 17:02:52','2024-02-01 17:02:52',1,1),(81,2,'MCC-0001','/home/amit/amit/FaceRecognitionFinel/static/uploads/MCC-0001.jpg','asdfasd','asdfdf','2024-02-01 17:09:36','2024-02-01 17:09:36',1,1),(82,2,'MCC-0001','/home/amit/amit/FaceRecognitionFinel/static/uploads/MCC-0001.jpg','asdfasd','asdfdf','2024-02-01 17:11:14','2024-02-01 17:11:14',1,1),(83,5,'MCC-0004','/home/amit/amit/FaceRecognitionFinel/static/uploads/MCC-0004.jpg','asdfasd','asdfdf','2024-02-01 17:22:28','2024-02-01 17:22:28',1,1),(84,6,'MCC-0005','/home/amit/amit/FaceRecognitionFinel/static/uploads/MCC-0005.jpg','asdfasd','asdfdf','2024-02-01 17:26:01','2024-02-01 17:26:01',1,1),(85,7,'MCC-0006','/home/amit/amit/FaceRecognitionFinel/static/uploads/MCC-0006.jpg','asdfasd','asdfdf','2024-02-01 17:35:20','2024-02-01 17:35:20',1,1),(86,18,'MCC-00017',NULL,'asdfasd','asdfdf','2024-02-02 17:46:15','2024-02-02 17:46:15',1,1),(87,18,'MCC-00017','/home/amit/amit/FaceRecognitionFinel/static/uploads/MCC-00017.jpg','asdfasd','asdfdf','2024-02-02 17:48:01','2024-02-02 17:48:01',1,1),(88,2,'MCC-0001','/home/amit/amit/FaceRecognitionFinel/MCC-0001.jpg','asdfasdfsd','asdfasdfsd','2024-02-02 18:36:07','2024-02-02 18:36:07',1,1),(89,2,'MCC-0001','/home/amit/amit/FaceRecognitionFinel/MCC-0001.jpg','asdfasdfsd','asdfasdfsd','2024-02-02 18:39:20','2024-02-02 18:39:20',1,1),(90,2,'MCC-0001','/home/amit/amit/FaceRecognitionFinel/MCC-0001.jpg','asdfasdfsd','asdfasdfsd','2024-02-02 18:40:38','2024-02-02 18:40:38',1,1),(91,2,'MCC-0001','/home/amit/amit/FaceRecognitionFinel/MCC-0001.jpg','asdfasdfsd','asdfasdfsd','2024-02-02 18:42:22','2024-02-02 18:42:22',1,1),(92,2,'MCC-0001','/home/amit/amit/FaceRecognitionFinel/static/uploads/MCC-0001.jpg','asdfasdfsd','asdfasdfsd','2024-02-02 18:42:38','2024-02-02 18:42:38',1,1),(93,8,'MCC-0007','/home/amit/amit/FaceRecognitionFinel/static/uploads/MCC-0007.jpg','asdfasd','asdfdf','2024-02-03 16:26:24','2024-02-03 16:26:24',1,1),(94,18,'MCC-00017','/home/amit/amit/FaceRecognitionFinel/static/uploads/MCC-00017.jpg','asdfasd','asdfdf','2024-02-04 04:30:05','2024-02-04 04:30:05',1,1),(95,18,'MCC-00017','/home/amit/amit/FaceRecognitionFinel/static/uploads/MCC-00017.jpg','asdfasd','asdfdf','2024-02-04 07:44:13','2024-02-04 07:44:13',1,1),(96,18,'MCC-00017','/home/amit/amit/FaceRecognitionFinel/static/uploads/MCC-00017.jpg','asdfasd','asdfdf','2024-02-04 08:01:48','2024-02-04 08:01:48',1,1),(97,18,'MCC-00017','/home/amit/amit/FaceRecognitionFinel/static/uploads/MCC-00017.jpg','asdfasd','asdfdf','2024-02-04 08:08:29','2024-02-04 08:08:29',1,1),(98,13,'MCC-00012','/home/amit/amit/FaceRecognitionFinel/static/uploads/MCC-00012.jpg','asdfasd','asdfdf','2024-02-04 08:12:28','2024-02-04 08:12:28',1,1);
/*!40000 ALTER TABLE `employee_image_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_termination`
--

DROP TABLE IF EXISTS `employee_termination`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_termination` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int unsigned NOT NULL,
  `termination_status` int unsigned NOT NULL,
  `termination_remarks` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `termination_date` date DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_termination`
--

LOCK TABLES `employee_termination` WRITE;
/*!40000 ALTER TABLE `employee_termination` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_termination` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employment_details`
--

DROP TABLE IF EXISTS `employment_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employment_details` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `joining_position` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `joining_location` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `zone_location` int NOT NULL DEFAULT '1',
  `joining_center` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `joining_date` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `reporting_time` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '9:00 AM',
  `pf_number` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `uan_number` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `esi_number` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `recruited_by` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `employment_details_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employment_details`
--

LOCK TABLES `employment_details` WRITE;
/*!40000 ALTER TABLE `employment_details` DISABLE KEYS */;
INSERT INTO `employment_details` VALUES (1,13,'1','12',39,'11','2018-06-01','9:00 AM','1100','3009','1200','HR',0,'2024-01-21 18:42:42','2024-01-21 18:42:42',1,1),(2,16,'1','12',39,'11','2018-06-01','9:00 AM','1100','3009','1200','HR',0,'2024-01-24 18:56:28','2024-01-24 18:56:28',1,1),(3,18,'1','12',39,'11','2018-06-01','9:00 AM','1100','3009','1200','HR',0,'2024-01-24 19:04:17','2024-01-24 19:04:17',1,1),(4,1,'1','12',39,'11','2018-06-01','9:00 AM','1100','3009','1200','HR',0,'2024-02-01 09:31:56','2024-02-01 09:31:57',1,1);
/*!40000 ALTER TABLE `employment_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `holidays`
--

DROP TABLE IF EXISTS `holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `holidays` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `holiday` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `is_deleted` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `holidays`
--

LOCK TABLES `holidays` WRITE;
/*!40000 ALTER TABLE `holidays` DISABLE KEYS */;
/*!40000 ALTER TABLE `holidays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `identification_details`
--

DROP TABLE IF EXISTS `identification_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `identification_details` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `adhaar_number` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `pan_card` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `license_number` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `identification_details_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `identification_details`
--

LOCK TABLES `identification_details` WRITE;
/*!40000 ALTER TABLE `identification_details` DISABLE KEYS */;
INSERT INTO `identification_details` VALUES (1,13,'209523390288','AGFPD6305V','DL-0420060328457',0,'2024-01-21 18:42:37','2024-01-21 18:42:37',1,1),(2,18,'209523390288','AGFPD6305V','DL-0420060328457',0,'2024-01-24 19:04:17','2024-01-24 19:04:17',1,1);
/*!40000 ALTER TABLE `identification_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `joining_positions`
--

DROP TABLE IF EXISTS `joining_positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `joining_positions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `position` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `joining_positions`
--

LOCK TABLES `joining_positions` WRITE;
/*!40000 ALTER TABLE `joining_positions` DISABLE KEYS */;
INSERT INTO `joining_positions` VALUES (1,'Co-Worker',0,'2024-01-30 08:54:45','2024-01-30 08:54:45',1,1),(2,'Director',0,'2024-01-30 09:03:31','2024-02-03 17:48:36',1,1),(3,'Team mamber',1,'2024-01-31 18:48:01','2024-01-31 19:27:14',1,1);
/*!40000 ALTER TABLE `joining_positions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES (1,'Noida2',1,'2024-01-21 22:31:45','2024-01-30 08:51:01',1,1),(2,'Delhi',0,'2024-01-30 08:49:01','2024-01-30 08:49:01',1,1),(3,'Delhi',0,'2024-01-30 08:49:31','2024-01-30 08:49:31',1,1);
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `misc_salary_components`
--

DROP TABLE IF EXISTS `misc_salary_components`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `misc_salary_components` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `center_id` int NOT NULL,
  `advance` double(8,2) NOT NULL,
  `reimbursement` double(8,2) NOT NULL,
  `date` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `remarks` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `misc_salary_components`
--

LOCK TABLES `misc_salary_components` WRITE;
/*!40000 ALTER TABLE `misc_salary_components` DISABLE KEYS */;
/*!40000 ALTER TABLE `misc_salary_components` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offer_letters`
--

DROP TABLE IF EXISTS `offer_letters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `offer_letters` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `address` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `manager` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `joining_date` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `joining_position` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `joining_location` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `joining_center` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `offer_letter_date` date NOT NULL,
  `offer_letter_subject` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `job_description` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `salary` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `working_hours` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `week_offs` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offer_letters`
--

LOCK TABLES `offer_letters` WRITE;
/*!40000 ALTER TABLE `offer_letters` DISABLE KEYS */;
/*!40000 ALTER TABLE `offer_letters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `user_id` int NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_modes`
--

DROP TABLE IF EXISTS `payment_modes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_modes` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `mode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_modes`
--

LOCK TABLES `payment_modes` WRITE;
/*!40000 ALTER TABLE `payment_modes` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_modes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipt_copies`
--

DROP TABLE IF EXISTS `receipt_copies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `receipt_copies` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `receipt_target` int NOT NULL,
  `receipt_for` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `receipt_link` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipt_copies`
--

LOCK TABLES `receipt_copies` WRITE;
/*!40000 ALTER TABLE `receipt_copies` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipt_copies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `request_logs`
--

DROP TABLE IF EXISTS `request_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_logs` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `request_header` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `request_body` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `request_type` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `request_url` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `status_code` int NOT NULL,
  `response_header` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `response_body` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `request_logs`
--

LOCK TABLES `request_logs` WRITE;
/*!40000 ALTER TABLE `request_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `request_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `role` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'SuperAdmin',0,'2024-01-20 14:01:38','2024-01-20 14:01:38',0,0),(2,'Admin',0,'2024-01-20 14:02:30','2024-01-20 14:02:30',0,0),(3,'HrAdmin',0,'2024-01-20 14:02:30','2024-01-20 14:02:30',0,0),(4,'Employee',0,'2024-01-21 06:32:23','2024-01-21 06:32:23',0,0);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salary_details`
--

DROP TABLE IF EXISTS `salary_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salary_details` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `base_salary` double(8,2) NOT NULL,
  `hra_salary` double(8,2) NOT NULL,
  `conveyance_salary` double(8,2) NOT NULL,
  `salary_active_date` date NOT NULL DEFAULT '2018-04-01',
  `payment_mode` int NOT NULL DEFAULT '2',
  `deduct_pf` tinyint NOT NULL DEFAULT '1',
  `deduct_esi` int NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `salary_details_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salary_details`
--

LOCK TABLES `salary_details` WRITE;
/*!40000 ALTER TABLE `salary_details` DISABLE KEYS */;
INSERT INTO `salary_details` VALUES (1,13,20000.00,6000.00,2000.00,'2018-04-01',2,1,0,0,'2024-01-21 18:42:45','2024-01-21 18:42:45',1,1),(2,16,20000.00,6000.00,2000.00,'2018-04-01',2,1,0,0,'2024-01-24 18:56:29','2024-01-24 18:56:29',1,1),(3,18,20000.00,6000.00,2000.00,'2018-04-01',2,1,0,0,'2024-01-24 19:04:18','2024-01-24 19:04:18',1,1);
/*!40000 ALTER TABLE `salary_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shift_timing`
--

DROP TABLE IF EXISTS `shift_timing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shift_timing` (
  `id` int NOT NULL AUTO_INCREMENT,
  `in_time` time NOT NULL,
  `out_time` time NOT NULL,
  `is_deleted` tinyint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shift_timing`
--

LOCK TABLES `shift_timing` WRITE;
/*!40000 ALTER TABLE `shift_timing` DISABLE KEYS */;
/*!40000 ALTER TABLE `shift_timing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stores`
--

DROP TABLE IF EXISTS `stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stores` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stores`
--

LOCK TABLES `stores` WRITE;
/*!40000 ALTER TABLE `stores` DISABLE KEYS */;
INSERT INTO `stores` VALUES (1,'Noida1',0,'2024-01-29 19:27:00','2024-01-30 08:48:13',1,1),(2,'Uttar Pradesh',0,'2024-01-30 07:14:16','2024-01-30 07:14:16',1,1),(3,'Uttar Pradesh',0,'2024-01-30 07:15:33','2024-01-30 07:15:33',1,1),(4,'Uttar Pradesh',0,'2024-01-30 08:45:12','2024-01-30 08:45:12',1,1),(5,'Uttar Pradesh',1,'2024-01-30 08:45:18','2024-01-30 08:46:48',1,1);
/*!40000 ALTER TABLE `stores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_details`
--

DROP TABLE IF EXISTS `user_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_details` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `first_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `last_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `profile_image` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `employee_id` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `father_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `husband_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `dob` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `contact_number` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `marital_status` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `previous_employer` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `current_address` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `permanant_address` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_details_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_details`
--

LOCK TABLES `user_details` WRITE;
/*!40000 ALTER TABLE `user_details` DISABLE KEYS */;
INSERT INTO `user_details` VALUES (1,9,'Emp2','kr','','MCC-0008','emp2@gmail.com','empFather','','top','724874929','0','top','Test Asset Model','',0,'2024-01-21 17:03:02','2024-01-21 17:03:02',1,1),(2,10,'Emp2','kr','','MCC-0009','emp2@gmail.com','empFather','','top','724874929','0','top','Test Asset Model','',0,'2024-01-21 17:51:41','2024-01-21 17:51:41',1,1),(3,11,'Emp2','kr','','MCC-00010','emp2@gmail.com','empFather','','top','724874929','0','top','Test Asset Model','',0,'2024-01-21 17:53:19','2024-01-21 17:53:19',1,1),(4,12,'Emp2','kr','','MCC-00011','emp2@gmail.com','empFather','','top','724874929','0','top','Test Asset Model','',0,'2024-01-21 18:39:16','2024-01-21 18:39:16',1,1),(5,13,'Emp2','kr','','MCC-00012','emp2@gmail.com','empFather','','top','724874929','0','top','Test Asset Model','',0,'2024-01-21 18:42:32','2024-01-21 18:42:32',1,1),(6,14,'Emp2','kr','','MCC-00013','emp2@gmail.com','empFather','','top','724874929','0','top','Test Asset Model','',0,'2024-01-21 19:33:57','2024-01-21 19:33:57',1,1),(7,15,'Emp14','kr','','MCC-00014','emp14@gmail.com','empFather','','top','724874929','0','top','Test Asset Model','',0,'2024-01-24 18:53:56','2024-01-24 18:53:56',1,1),(8,16,'Emp15','kr','','MCC-00015','emp15@gmail.com','empFather','','top','724874929','0','top','Test Asset Model','',0,'2024-01-24 18:56:25','2024-01-24 18:56:25',1,1),(9,18,'Emp17','kr','','MCC-00017','emp17@gmail.com','empFather','','top','724874920','0','top','Test Asset Model','',0,'2024-01-24 19:04:15','2024-01-24 19:04:15',1,1);
/*!40000 ALTER TABLE `user_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_otp_secrets`
--

DROP TABLE IF EXISTS `user_otp_secrets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_otp_secrets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) NOT NULL,
  `otp_secret` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_otp_secrets`
--

LOCK TABLES `user_otp_secrets` WRITE;
/*!40000 ALTER TABLE `user_otp_secrets` DISABLE KEYS */;
INSERT INTO `user_otp_secrets` VALUES (1,'18','','2024-01-30 17:21:35','2024-01-30 17:21:35','2024-01-27 18:01:31','2024-01-30 17:21:35'),(2,'1','967203','2024-01-31 14:16:27','2024-01-31 14:16:27','2024-01-31 13:26:48','2024-01-31 14:16:27'),(3,'23','583759','2024-02-01 10:32:27','2024-02-01 10:32:27','2024-01-31 15:45:37','2024-02-01 10:32:27');
/*!40000 ALTER TABLE `user_otp_secrets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `username` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `role` int NOT NULL,
  `is_rejoin` int NOT NULL DEFAULT '0',
  `api_token` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `is_locked` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_face_registerd` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Marscare','hrAdmin','marscare@gmail.com','$2a$10$6KseuLASDfSqV8BVg7gI1.hX8miQFpOnd454B/5ofIWW/PElnvVuy',3,0,'',NULL,0,0,1,'2024-01-20 14:03:42','2024-01-20 14:03:42',0,0),(2,'assest2','MCC-0001','MCC-0001','$2a$10$4iFzpJekSuy7Ve3Ab8HgWux6FQNE6w2d4/b4RgQ1Qv7zZc4.gwVdS',4,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImhyQWRtaW4iLCJpYXQiOjE3MDU4NDg5OTMsImV4cCI6MTcwNTg1MDc5M30.Cqkn-gn0SqZkSTNldNXxm0HSMCf70-p74wj9Ivl-Epo',NULL,0,0,1,'2024-01-21 15:10:11','2024-01-21 15:10:11',0,0),(3,'Emp2','MCC-0002','emp2@gmail.com','$2a$10$ftrdPgi7nb1Zp0CQ88ZBkOZt/Yn6UeYCtHj.fFt1Anzu9d/mUOPYK',4,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNTg1NDAyNCwiZXhwIjoxNzA1ODU1ODI0fQ._xD3Ycr3IKj0Ft-jpIBNi5sc1RbDNw0mgOWChU6huHg',NULL,0,0,1,'2024-01-21 16:20:42','2024-01-21 16:20:42',1,1),(4,'Emp2','MCC-0003','emp2@gmail.com','$2a$10$S8J/4Z9zedobJnWM1zQrI.OfyPzsqc91NduWk/ICi5n8erJA.QsyO',4,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNTg1NDAyNCwiZXhwIjoxNzA1ODU1ODI0fQ._xD3Ycr3IKj0Ft-jpIBNi5sc1RbDNw0mgOWChU6huHg',NULL,0,0,1,'2024-01-21 16:38:08','2024-01-21 16:38:08',1,1),(5,'Emp2','MCC-0004','emp2@gmail.com','$2a$10$bK9vet63/Y.bMA8VgEpy3ePh//ZgM.8h1hBV0WR2DHtc9g7fUJlIu',4,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNTg1NDAyNCwiZXhwIjoxNzA1ODU1ODI0fQ._xD3Ycr3IKj0Ft-jpIBNi5sc1RbDNw0mgOWChU6huHg',NULL,0,0,1,'2024-01-21 16:43:28','2024-01-21 16:43:28',1,1),(6,'Emp2','MCC-0005','emp2@gmail.com','$2a$10$3IbIttJKcLxf.oXqEo6UBOhuZBAyyH89OSXuZDfRKLOt1qlPfRAfG',4,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNTg1NDAyNCwiZXhwIjoxNzA1ODU1ODI0fQ._xD3Ycr3IKj0Ft-jpIBNi5sc1RbDNw0mgOWChU6huHg',NULL,0,0,1,'2024-01-21 16:49:07','2024-01-21 16:49:07',1,1),(7,'Emp2','MCC-0006','emp2@gmail.com','$2a$10$Z8OoQfhx6gGRiYg0CP0nXenb4N7Ljz74HyCAcKTNKjV263PFrJaje',4,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNTg1NjA1OSwiZXhwIjoxNzA1ODU3ODU5fQ.vqo3PuztUt2iI61sX86rNGwsfx3GCj4xdRAkAOhyy78',NULL,0,0,1,'2024-01-21 16:55:03','2024-01-21 16:55:03',1,1),(8,'Emp2','MCC-0007','emp2@gmail.com','$2a$10$.XwBZCLhr8Q50f32sCTenepIZX/O6TMLFy6rRFu6toEwZAYbPDGCq',4,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNTg1NjA1OSwiZXhwIjoxNzA1ODU3ODU5fQ.vqo3PuztUt2iI61sX86rNGwsfx3GCj4xdRAkAOhyy78',NULL,0,0,1,'2024-01-21 17:00:05','2024-01-21 17:00:05',1,1),(9,'Emp2','MCC-0008','emp2@gmail.com','$2a$10$WDIVy7JIQhZiyKZ1qfSO/edME5j0Ue4F/E/8Zj87qv3Kr6Zex6gKm',4,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNTg1NjA1OSwiZXhwIjoxNzA1ODU3ODU5fQ.vqo3PuztUt2iI61sX86rNGwsfx3GCj4xdRAkAOhyy78',NULL,0,0,0,'2024-01-21 17:03:02','2024-01-21 17:03:02',1,1),(10,'Emp2','MCC-0009','emp2@gmail.com','$2a$10$4zTnNZvNWY3tDW9eiIEOs.5E.zakThq3ms2VvjRoHiNKfdgzvtDde',4,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNTg1OTQ4NSwiZXhwIjoxNzA1ODYxMjg1fQ.ULmNcdsMFT0MtWC2Xjxf7XMBT6qZmbHA4GTnEb1n62w',NULL,0,0,0,'2024-01-21 17:51:41','2024-01-21 17:51:41',1,1),(11,'Emp2','MCC-00010','emp2@gmail.com','$2a$10$MLp2d2l0jMT.lmEP1vOK9OVj626Jh1g0fK5FPeoOldb/j5HWzNbOy',4,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNTg1OTQ4NSwiZXhwIjoxNzA1ODYxMjg1fQ.ULmNcdsMFT0MtWC2Xjxf7XMBT6qZmbHA4GTnEb1n62w',NULL,0,0,0,'2024-01-21 17:53:19','2024-01-21 17:53:19',1,1),(12,'Emp2','MCC-00011','emp2@gmail.com','$2a$10$r.0OAYTLeJy1OsJL4tnkIeN5t4daNNwWpCd3sbz/mN5UxB8LrJbOe',4,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNTg2MjI1NiwiZXhwIjoxNzA1OTQ4NjU2fQ.G9vX0PvEi43VFeiqN8fZpFnmE7R-ykuVVLE0k7TGbOg',NULL,0,0,0,'2024-01-21 18:39:16','2024-01-21 18:39:16',1,1),(13,'Emp2','MCC-00012','emp2@gmail.com','$2a$10$uJzkRXhrHe8Jn2TEIyPmEOZfVLnmleA8FWe/sWid2nyEBhUuHhub2',4,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNTg2MjI1NiwiZXhwIjoxNzA1OTQ4NjU2fQ.G9vX0PvEi43VFeiqN8fZpFnmE7R-ykuVVLE0k7TGbOg',NULL,0,0,1,'2024-01-21 18:42:32','2024-01-21 18:42:32',1,1),(14,'Emp2 kr','MCC-00013','emp2@gmail.com','$2a$10$eOY4b6gbJK8AEqthILPuVOPhw3DoNT1.pY0lO/jqoF5YX15Oa1Atq',4,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNTg2MjI1NiwiZXhwIjoxNzA1OTQ4NjU2fQ.G9vX0PvEi43VFeiqN8fZpFnmE7R-ykuVVLE0k7TGbOg',NULL,0,0,0,'2024-01-21 19:33:53','2024-01-21 19:33:53',1,1),(15,'Emp14 kr','MCC-00014','emp14@gmail.com','$2a$10$ttlH0QHp7qzS4DNWjdxZYO4MP1.dUJE1XsMqKIejWzQdwS00mjUiS',4,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNjExNzUwNywiZXhwIjoxNzA2MjAzOTA3fQ.aWfrq0ulRYODE9kZWt4-Q0FXBDYajORG_V_dhM5dqKg',NULL,0,0,0,'2024-01-24 18:53:50','2024-01-24 18:53:50',1,1),(16,'Emp15 kr','MCC-00015','emp15@gmail.com','$2a$10$nUKmJHB645/75f1lurbaH.blf9aYj7Ag5AKKwD4LGjLFWXM9EBrTi',4,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNjExNzUwNywiZXhwIjoxNzA2MjAzOTA3fQ.aWfrq0ulRYODE9kZWt4-Q0FXBDYajORG_V_dhM5dqKg',NULL,0,0,0,'2024-01-24 18:56:19','2024-01-24 18:56:19',1,1),(17,'Emp16 kr','MCC-00016','emp16@gmail.com','$2a$10$LJKVgPLVZJFTHGq5QREk4uAEM3.36TQymbHQlR0A68CCV5KJJDSgy',4,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNjExNzUwNywiZXhwIjoxNzA2MjAzOTA3fQ.aWfrq0ulRYODE9kZWt4-Q0FXBDYajORG_V_dhM5dqKg',NULL,0,0,0,'2024-01-24 19:00:33','2024-01-24 19:00:33',1,1),(18,'Emp17 kr','MCC-00017','blazittechnology@gmail.com','$2a$10$lFno40p1Bal0a0nNbPD9xOO5P9IpWig.bJVWBjXXL0scDaZu1XOKu',4,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNjExNzUwNywiZXhwIjoxNzA2MjAzOTA3fQ.aWfrq0ulRYODE9kZWt4-Q0FXBDYajORG_V_dhM5dqKg',NULL,0,0,1,'2024-01-24 19:04:14','2024-01-24 19:04:14',1,1),(19,'Naveen','9845699985','naveen1@gmail.com','$2a$10$.o7j30JERbaT3vZdghmM1.v8s9AFwGIDtbv./eVOIYgNy97ToOeT.',5,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNjQ3MTU0MiwiZXhwIjoxNzA2NTU3OTQyfQ.cZK8bDmFueOd07XPgb0K6-r43j-2fc9T96Xmfuw13wk',NULL,0,1,0,'2024-01-28 23:12:56','2024-01-30 18:22:57',1,1),(20,'Binit','9845699986','Binit@gmail.com','$2a$10$tHJ4uzgzl93d1/TaOckS8eDbNv.35qxpB/BZyqXy7vA.bVqoI/O3u',5,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNjYwNDI4MiwiZXhwIjoxNzA2NjkwNjgyfQ.sVWsr5vUN25pSycjddhbKeANUQQnIMsM8yM6IkhEEtQ',NULL,0,0,0,'2024-01-30 18:35:51','2024-01-31 08:34:46',1,1),(21,'Binit333333333','9845699935','Binit1@gmail.com','$2a$10$dT2WAJ0SUJTCa0kb6/zXee582nA2t.8.OART1i5MWgDDBFMRtZpQK',5,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNjYwNDI4MiwiZXhwIjoxNzA2NjkwNjgyfQ.sVWsr5vUN25pSycjddhbKeANUQQnIMsM8yM6IkhEEtQ',NULL,0,1,0,'2024-01-31 04:23:54','2024-01-31 08:41:36',1,1),(22,'kljlkj kjl','1','lkjkl@gmail.com','$2a$10$EBhUWgyJzgMOv55Qv.O4/Oh/x6FDxzbHL.9HOd4gnlcShL0I/fwoi',4,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNjY4NDk3MSwiZXhwIjoxNzA2NzcxMzcxfQ.i_WYrfbhxvzunf2vhBltGirnzEX3VUDU_hWogGcALfQ',NULL,0,0,0,'2024-01-31 12:19:51','2024-01-31 12:19:51',1,1),(23,'Emp25 kr','MCC-00025','mohitmishrahere@gmail.com','$2a$10$Ikj35x3iml269ZT8iiNQQ.n4YMxRp6n63Eteg1qrORBdJNi8fjgqG',4,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNjcwMTYxNCwiZXhwIjoxNzA2Nzg4MDE0fQ.qCEACsT4DiWFlhhynKvK6d6QCVGddtrztWveWaet9w4',NULL,0,0,0,'2024-01-31 14:18:56','2024-01-31 14:18:56',1,1),(24,'amit sinha','MCC-00026','ak.amit1682@gmail.com','$2a$10$fBymDA2djRC.IWdHrh72vu5Ik82dlrbvgVwBKWfUppOqcwdPYLPRG',4,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNjcwMTYxNCwiZXhwIjoxNzA2Nzg4MDE0fQ.qCEACsT4DiWFlhhynKvK6d6QCVGddtrztWveWaet9w4',NULL,0,0,0,'2024-01-31 18:10:37','2024-01-31 18:10:37',1,1),(25,'amitkr sinha','MCC-00027','ak.amit168e@gmail.com','$2a$10$ZK09PHPPu8RGRN6F29KXPuwDF4VlMtThBbfRi9WD/r4bPaCgG0Qbm',4,0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNjcwMTYxNCwiZXhwIjoxNzA2Nzg4MDE0fQ.qCEACsT4DiWFlhhynKvK6d6QCVGddtrztWveWaet9w4',NULL,0,0,0,'2024-01-31 18:13:20','2024-02-01 09:31:57',1,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `week_off`
--

DROP TABLE IF EXISTS `week_off`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `week_off` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int unsigned NOT NULL,
  `center_id` int unsigned NOT NULL,
  `week_off` int unsigned NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `week_off_employee_id_foreign` (`employee_id`),
  KEY `week_off_center_id_foreign` (`center_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `week_off`
--

LOCK TABLES `week_off` WRITE;
/*!40000 ALTER TABLE `week_off` DISABLE KEYS */;
/*!40000 ALTER TABLE `week_off` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-09  3:15:02
